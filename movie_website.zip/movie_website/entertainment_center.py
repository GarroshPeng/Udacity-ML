# !/usr/bin/python
# -*- coding: utf-8 -*-
import media
import fresh_tomatoes
# 创建 movie实例
toy_story=media.Movie("英伦对决","成龙布鲁斯南飙戏","http://r1.ykimg.com/0516000059C4A504859B5D02FC0D5A77","http://v.youku.com/v_show/id_XMzE4ODk0NDczMg==.html")
toy_story2=media.Movie("功守道","a rich man battle famous kongfuStar","http://r1.ykimg.com/051600005A07EC22ADBC092D8C0A7FB4","http://v.youku.com/v_show/id_XMzE0ODM1ODg1Ng==.html?spm=a2hmv.20009921.topNav.5~1~3!3~1~3!2~A")

# 创建movie列表
list=[toy_story,toy_story2]
# 生成并打开页面
fresh_tomatoes.open_movies_page(list)
